package com.workers.jdbcexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcExampleApplication.class, args);
	}

}
